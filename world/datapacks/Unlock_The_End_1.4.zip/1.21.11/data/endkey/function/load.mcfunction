# scoreboards
scoreboard objectives add endkey.data dummy
scoreboard objectives add endkey.unlockDelay dummy

# gamerules
gamerule command_block_output false
gamerule command_blocks_work true
gamerule max_block_modifications 2147483647